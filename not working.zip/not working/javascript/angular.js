var app= angular.module("myApp",['ngRoute','checklist-model']);
app.config(['$routeProvider', function($routeProvider){
                $routeProvider
                .when('/',
							{
							controller: 'indexController',
							templateUrl:'pages/home.html'})
                .when('/editAuthor',
                    {
							controller: 'authorEditController',
							templateUrl:'pages/authorEdit.html'})
				.when('/editBook',
                    {
							controller: 'bookEditController',
							templateUrl:'pages/bookEdit.html'})
				.when('/newAuthor',
                    {
							controller: 'authorNewController',
							templateUrl:'pages/authorNew.html'})
				.when('/newBook',
                    {
							controller: 'bookNewController',
							templateUrl:'pages/bookNew.html'})
                .otherwise({redirectTo:'/'});
            }]);
			
			
/*Home page*/
app.controller("indexController",function($scope,$http){

$http.get("http://172.27.12.104:3000/book/list")

.success(function(data){
$scope.bookData = data;
})
.error(function(data) {

    });
});

/*Book Edit Page*/
app.controller("bookEditController",function($scope){
$scope.fun ="TP";
});

/*Creating an object*/
app.factory('dataSetFunc',function(){
	var dataSet = { 
	skillSet :[
	{id: 1 , value:'HTML', checked:'false'},
	{id: 2, value: 'CSS' , checked:'false'},
	{id: 3, value: 'Java' , checked:'false'},
	{id: 4, value: 'JavaScript' , checked:'false'},
	{id: 5, value: 'Node.js' , checked:'false'},
	{id: 6, value: 'Knockout' , checked:'false'},
	{id: 7, value: 'Angular' , checked:'false'},
	{id: 8, value: 'Go' , checked:'false'},
	{id: 9, value: 'PHP' , checked:'false'},
	{id: 10, value: 'Backbone' , checked:'false'},
	{id: 11, value: 'React' , checked:'false'},
	{id: 12, value: 'Project Management' , checked:'false'},
	{id: 13, value: 'Communication' , checked:'false'},
	{id: 14, value: 'Delivery Management' , checked:'false'}],
	
	departmentSet :[
	{dept:'Engineering',selected :'false'},
	{dept:'Management',selected:'true'},
	{dept:'Housekeeping',selected:'false'}
	]};
	
	
	return { dataSet };
});


/*Author Edit Page*/
app.controller("authorEditController",function($scope,$http,$location,dataSetFunc){
	/*function ($scope, dataSetFunc) {
    $scope.dataSet = dataSetFunc;
 };*/

$scope.authorDetailsData =  dataSetFunc;
var myUrl = $location.search().author;
var request = $http({
                    method: "post",
                    url: "http://172.27.12.104:3000/author/byname",
                    data: {"name" : myUrl}
                });
request.success(function(data){
$scope.authorDetails = data;

})
request.error(function(data) {

  });
    
  
});

/*Author New Page*/
app.controller("authorNewController",function($scope,$http,dataSetFunc){
$scope.authorNewDetailsData = dataSetFunc;


 $scope.toggleUserSkills = function(skills){
        if($scope.authorNew.indexOf(skills) == -1){
          $scope.authorNew.push(skills);
        } 
        else{
          $scope.user.roles.splice($scope.authorNewDetails.skills.indexOf(skills),1);
        }
		console.log("in");
		console.log("out");
      };

$scope.addNewAuthor = function (authorNewDetails){	

console.log("$scope.skillse");
$scope.authorNewDetails = {skills:[]};
console.log($scope.authorNewDetails.skills);


var request = $http({
                    method: "post",
                    url: "http://172.27.12.104:3000/author/new " ,
                    data: authorNewDetails
                });
request.success(function(data){
$scope.bookDetails = data;
})
request.error(function(data) {

});
}
});

/*Book Edit Page*/
app.controller("bookEditController",function($scope,$http,$location){
var myUrl = $location.search().book;
var request = $http({
                    method: "post",
                    url: "http://172.27.12.104:3000/book/byisbn" ,
                    data: {"isbn" : myUrl}
                });
request.success(function(data){
$scope.bookDetails = data;
})
request.error(function(data) {

  });

});






