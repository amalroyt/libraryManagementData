var app= angular.module("myApp",['ngRoute']);
app.config(['$routeProvider', function($routeProvider){
                $routeProvider
                .when('/',
							{
							controller: 'indexController',
							templateUrl:'pages/home.html'})
                .when('/editAuthor',
                    {
							controller: 'authorEditController',
							templateUrl:'pages/authorEdit.html'})
				.when('/editBook',
                    {
							controller: 'bookEditController',
							templateUrl:'pages/bookEdit.html'})
				.when('/newAuthor',
                    {
							controller: 'authorNewController',
							templateUrl:'pages/authorNew.html'})
				.when('/newBook',
                    {
							controller: 'bookNewController',
							templateUrl:'pages/bookNew.html'})
                .otherwise({redirectTo:'/'});
            }]);
			
			
/*Home page*/
app.controller("indexController",function($scope,$http){

$http.get("http://172.27.12.104:3000/book/list")

.success(function(data){
$scope.bookData = data;
})
.error(function(data) {

    });
});

/*Book Edit Page*/
app.controller("bookEditController",function($scope){
$scope.fun ="TP";
});

/*Creating an object*/
app.factory('skillFunc',function(){
	return { Set : ['HTML','CSS','Java','JavaScript','Node.js','Knockout','Angular','Go','PHP','Backbone','React','Project Management','Communication','Delivery Management']
};
});


/*Author Edit Page*/
app.controller("authorEditController",function($scope,$http,$location,skillFunc){
$scope.skillSet = skillFunc.Set;
var set = $scope.skillSet;
var myUrl = $location.search().author;
var request = $http({
                    method: "post",
                    url: "http://172.27.12.104:3000/author/byname",
                    data: {"name" : myUrl}
                });
request.success(function(data){
$scope.authorDetails = data;
console.log(data.skills.indexOf(set[3]) > -1);
})
request.error(function(data) {

  });
    
  
});

/*Author New Page*/
app.controller("authorNewController",function($scope,$http,$location){

$scope.addNewAuthor = function (){
	console.log($scope.authorNewDetails.department.value);
	if ($scope.authorNewDetails.department.value == 'Management')
		console.log("success");
	else
		console.log("failure");
};
	
/*var request = $http({
                    method: "post",
                    url: "http://172.27.12.104:3000/author/new " ,
                    data: { "empid": $scope.authorNewDetails.empid, 
					"name": $scope.authorNewDetails.name,
					"email": $scope.authorNewDetails.email,
					"website": $scope.authorNewDetails.website,
					"department": $scope.authorNewDetails.department,
					"skills": $scope.authorNewDetails.skills  }
                });
request.success(function(data){
$scope.bookDetails = data;
})
request.error(function(data) {

});*/

});

/*Book Edit Page*/
app.controller("bookEditController",function($scope,$http,$location){
var myUrl = $location.search().book;
var request = $http({
                    method: "post",
                    url: "http://172.27.12.104:3000/book/byisbn" ,
                    data: {"isbn" : myUrl}
                });
request.success(function(data){
$scope.bookDetails = data;
})
request.error(function(data) {

  });

});






